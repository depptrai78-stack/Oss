package com.krypton.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import net.minecraft.world.chunk.ChunkToNibbleArrayMap;
import net.minecraft.world.chunk.light.LightStorage;

@Mixin(LightStorage.class)
public interface LightStorageAccessor {
    @Accessor("storage")
    ChunkToNibbleArrayMap<?> getStorage();
}

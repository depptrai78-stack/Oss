package com.krypton.mixin;

import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import net.minecraft.world.chunk.ChunkNibbleArray;
import net.minecraft.world.chunk.ChunkToNibbleArrayMap;

@Mixin(ChunkToNibbleArrayMap.class)
public interface ChunkToNibbleArrayMapAccessor {
    @Accessor("arrays")
    Long2ObjectOpenHashMap<ChunkNibbleArray> getArrays();
}

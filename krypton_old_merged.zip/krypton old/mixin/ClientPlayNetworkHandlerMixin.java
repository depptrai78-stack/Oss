package com.krypton.mixin;

import com.krypton.KryptonPort;
import com.krypton.event.ChunkDataEvent;
import com.krypton.event.EntitySpawnEvent;
import com.krypton.event.GameJoinEvent;
import com.krypton.event.TotemPopEvent;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.entity.EntityStatuses;
import net.minecraft.network.packet.s2c.play.ChunkDataS2CPacket;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.s2c.play.GameJoinS2CPacket;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public class ClientPlayNetworkHandlerMixin {
   private static final String FORCE_MAIN_THREAD =
         "Lnet/minecraft/network/NetworkThreadUtils;forceMainThread("
               + "Lnet/minecraft/network/packet/Packet;"
               + "Lnet/minecraft/network/listener/PacketListener;"
               + "Lnet/minecraft/network/PacketApplyBatcher;)V";

   @Inject(method = "onChunkData", at = @At("TAIL"))
   private void krypton$onChunkData(ChunkDataS2CPacket packet, CallbackInfo ci) {
      KryptonPort.EVENTS.post(new ChunkDataEvent(packet));
   }

   @Inject(method = "onEntitySpawn",
           at = @At(value = "INVOKE", target = FORCE_MAIN_THREAD, shift = At.Shift.AFTER),
           cancellable = true)
   private void krypton$onEntitySpawn(EntitySpawnS2CPacket packet, CallbackInfo ci) {
      EntitySpawnEvent event = new EntitySpawnEvent(packet);
      KryptonPort.EVENTS.post(event);
      if (event.isCancelled()) {
         ci.cancel();
      }
   }

   @Inject(method = "onGameJoin", at = @At("TAIL"))
   private void krypton$onGameJoin(GameJoinS2CPacket packet, CallbackInfo ci) {
      KryptonPort.EVENTS.post(new GameJoinEvent());
   }

   @Inject(method = "onEntityStatus", at = @At("TAIL"))
   private void krypton$onEntityStatus(EntityStatusS2CPacket packet, CallbackInfo ci) {
      if (packet.getStatus() != EntityStatuses.USE_TOTEM_OF_UNDYING) {
         return;
      }

      MinecraftClient client = MinecraftClient.getInstance();
      if (client.world == null || client.player == null) {
         return;
      }

      if (packet.getEntity(client.world) == client.player) {
         KryptonPort.EVENTS.post(new TotemPopEvent());
      }
   }
}

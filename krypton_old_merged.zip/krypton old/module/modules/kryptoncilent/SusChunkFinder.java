package com.krypton.modules.basefinding;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Predicate;

import com.krypton.event.ChunkDataEvent;
import com.krypton.event.EventHandler;
import com.krypton.event.Render3DEvent;
import com.krypton.settings.BoolSetting;
import com.krypton.settings.NumberSetting;
import com.krypton.settings.Setting;
import com.krypton.system.Category;
import com.krypton.system.Module;
import com.krypton.util.Color;
import com.krypton.util.ShapeMode;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

public class SusChunkFinder extends Module {
   public record ChunkScore(int selfHeat, boolean hasUngrown, Set<BlockPos> rotated) {
   }

   public NumberSetting simulationDistance;

   public NumberSetting sensitivity;

   public NumberSetting alpha;

   public BoolSetting kelp;

   public BoolSetting caveVines;

   public BoolSetting vines;

   public BoolSetting amethyst;

   public BoolSetting bamboo;

   public BoolSetting beeNest;

   public BoolSetting rotatedDeepslate;

   public ConcurrentHashMap<ChunkPos, Integer> heat;

   public ConcurrentHashMap<ChunkPos, Integer> vetoes;

   public Set<ChunkPos> scannedChunks;

   public Set<BlockPos> rotatedPositions;

   public ConcurrentHashMap<ChunkPos, Set<BlockPos>> chunkRotated;

   public ConcurrentHashMap<ChunkPos, Integer> chunkScore;

   public ConcurrentHashMap<ChunkPos, Boolean> chunkUngrown;

   public ExecutorService scanner;

   public SusChunkFinder() {
      super("Sus Chunk Finder", "Finds probable base locations using plant/amethyst growth and rotated deepslate", -1, Category.BASE_FINDING);

      this.simulationDistance = new NumberSetting("Simulation Distance", 2.0, 16.0, 4.0, 1.0);
      this.sensitivity = new NumberSetting("Sensitivity", 1.0, 20.0, 3.0, 1.0)
            .description("Minimum grown things needed to mark chunk as sus");
      this.alpha = new NumberSetting("Alpha", 10.0, 255.0, 80.0, 1.0);
      this.kelp = new BoolSetting("Kelp", true);
      this.caveVines = new BoolSetting("Cave Vines", true);
      this.vines = new BoolSetting("Vines", true);
      this.amethyst = new BoolSetting("Amethyst", true);
      this.bamboo = new BoolSetting("Bamboo", true);
      this.beeNest = new BoolSetting("Bee Nest", true)
            .description("Bee nests with honey means someone loaded the chunk");
      this.rotatedDeepslate = new BoolSetting("Rotated Deepslate", true)
            .description("Detect rotated deepslate buried between Y 0-60");

      this.heat = new ConcurrentHashMap<>();
      this.vetoes = new ConcurrentHashMap<>();
      this.scannedChunks = ConcurrentHashMap.newKeySet();
      this.rotatedPositions = ConcurrentHashMap.newKeySet();
      this.chunkRotated = new ConcurrentHashMap<>();
      this.chunkScore = new ConcurrentHashMap<>();
      this.chunkUngrown = new ConcurrentHashMap<>();

      this.addSettings(new Setting[] {
         this.simulationDistance, this.sensitivity, this.alpha, this.kelp, this.caveVines,
         this.vines, this.amethyst, this.bamboo, this.beeNest, this.rotatedDeepslate
      });
   }

   @Override
   public void onEnable() {
      this.scanner = Executors.newSingleThreadExecutor();
   }

   @Override
   public void onDisable() {
      super.onDisable();
      if (this.scanner != null && !this.scanner.isShutdown()) {
         this.scanner.shutdownNow();
      }

      this.heat.clear();
      this.vetoes.clear();
      this.scannedChunks.clear();
      this.rotatedPositions.clear();
      this.chunkRotated.clear();
      this.chunkScore.clear();
      this.chunkUngrown.clear();
   }

   @EventHandler
   public void onChunkData(ChunkDataEvent event) {
      if (this.mc.world != null) {
         ChunkPos pos = new ChunkPos(event.packet.getChunkX(), event.packet.getChunkZ());
         WorldChunk chunk = this.mc.world.getChunk(pos.x, pos.z);
         this.submitChunkScan(chunk);
      }
   }

   public void submitChunkScan(WorldChunk chunk) {
      if (this.scanner != null && !this.scanner.isShutdown()) {
         if (chunk == null) {
            return;
         }

         this.scanner.submit(() -> {
            if (this.isEnabled() && this.mc.world != null) {
               ChunkPos pos = chunk.getPos();
               this.scannedChunks.add(pos);
               this.updateChunk(pos, chunk);
               return;
            }
         });
      }
   }

   public void updateChunk(ChunkPos pos, WorldChunk chunk) {
      int distance = this.simulationDistance.getInt();
      final int previousScore = this.chunkScore.getOrDefault(pos, 0);
      boolean previousUngrown = Boolean.TRUE.equals(this.chunkUngrown.get(pos));
      Set<BlockPos> previousRotated = this.chunkRotated.remove(pos);
      if (previousScore > 0) {
         for (int dx = -distance; dx <= distance; dx++) {
            for (int dz = -distance; dz <= distance; dz++) {
               ChunkPos neighbour = new ChunkPos(pos.x + dx, pos.z + dz);
               this.heat.compute(neighbour, (key, value) -> {
                  int left = (value == null ? 0 : value) - previousScore;
                  return left <= 0 ? null : left;
               });
            }
         }
      }

      if (previousUngrown) {
         for (int dx = -distance; dx <= distance; dx++) {
            for (int dz = -distance; dz <= distance; dz++) {
               this.removeVeto(new ChunkPos(pos.x + dx, pos.z + dz));
            }
         }
      }

      if (previousRotated != null && !previousRotated.isEmpty()) {
         this.rotatedPositions.removeAll(previousRotated);
      }

      ChunkScore score = this.scoreChunk(pos, chunk);
      this.chunkScore.put(pos, score.selfHeat());
      this.chunkUngrown.put(pos, score.hasUngrown());
      if (score.hasUngrown()) {
         for (int dx = -distance; dx <= distance; dx++) {
            for (int dz = -distance; dz <= distance; dz++) {
               this.addVeto(new ChunkPos(pos.x + dx, pos.z + dz));
            }
         }
      }

      if (score.selfHeat() > 0) {
         for (int dx = -distance; dx <= distance; dx++) {
            for (int dz = -distance; dz <= distance; dz++) {
               ChunkPos neighbour = new ChunkPos(pos.x + dx, pos.z + dz);
               this.heat.merge(neighbour, score.selfHeat(), Integer::sum);
            }
         }
      }

      if (!score.rotated().isEmpty()) {
         this.chunkRotated.put(pos, score.rotated());
         this.rotatedPositions.addAll(score.rotated());
      }
   }

   public void addVeto(ChunkPos pos) {
      this.vetoes.merge(pos, 1, Integer::sum);
   }

   public void removeVeto(ChunkPos pos) {
      this.vetoes.compute(pos, (key, value) -> {
         if (value == null) {
            return null;
         } else {
            int left = value - 1;
            return left <= 0 ? null : left;
         }
      });
   }

   public boolean isVetoed(ChunkPos pos) {
      return this.vetoes.containsKey(pos);
   }

   public ChunkScore scoreChunk(ChunkPos pos, WorldChunk chunk) {
      ChunkSection[] sections = chunk.getSectionArray();
      int bottomSectionCoord = chunk.getBottomSectionCoord();
      int startX = pos.getStartX();
      int startZ = pos.getStartZ();
      int grownKelp = 0;
      int ungrownKelp = 0;
      int grownCaveVines = 0;
      int ungrownCaveVines = 0;
      int grownVines = 0;
      int ungrownVines = 0;
      int grownAmethyst = 0;
      int ungrownAmethyst = 0;
      int grownBamboo = 0;
      int ungrownBamboo = 0;
      int grownBeeNest = 0;
      int ungrownBeeNest = 0;
      boolean donut = this.amethyst.get() && this.isDonutFolia();
      boolean anyBud = false;
      boolean anyCluster = false;
      Set<BlockPos> rotated = ConcurrentHashMap.newKeySet();

      for (int i = 0; i < sections.length; i++) {
         ChunkSection section = sections[i];
         if (section != null && !section.isEmpty()) {
            int sectionY = bottomSectionCoord + i << 4;
            if (donut) {
               if (!anyBud) {
                  Predicate<BlockState> buds = state -> state.getBlock() == Blocks.SMALL_AMETHYST_BUD
                        || state.getBlock() == Blocks.MEDIUM_AMETHYST_BUD
                        || state.getBlock() == Blocks.LARGE_AMETHYST_BUD;
                  if (section.hasAny(buds)) {
                     anyBud = true;
                  }
               }

               if (!anyCluster) {
                  Predicate<BlockState> clusters = state -> state.getBlock() == Blocks.AMETHYST_CLUSTER;
                  if (section.hasAny(clusters)) {
                     anyCluster = true;
                  }
               }
            }

            for (int lx = 0; lx < 16; lx++) {
               for (int ly = 0; ly < 16; ly++) {
                  for (int lz = 0; lz < 16; lz++) {
                     BlockState state = section.getBlockState(lx, ly, lz);
                     int x = startX + lx;
                     int y = sectionY + ly;
                     int z = startZ + lz;
                     if (this.kelp.get()) {
                        if (state.isOf(Blocks.KELP)) {
                           if (state.contains(Properties.AGE_25)) {
                              int age = state.get(Properties.AGE_25);
                              BlockPos above = new BlockPos(x, y + 1, z);
                              boolean waterAbove = this.mc.world.getBlockState(above).isOf(Blocks.WATER);
                              if (age != 25 && waterAbove) {
                                 ungrownKelp++;
                              } else {
                                 grownKelp++;
                              }
                           }
                        }
                     }

                     if (this.caveVines.get()) {
                        if (state.isOf(Blocks.CAVE_VINES)) {
                           if (state.contains(Properties.AGE_25)) {
                              int age = state.get(Properties.AGE_25);
                              BlockPos below = new BlockPos(x, y - 1, z);
                              boolean airBelow = this.mc.world.getBlockState(below).isAir();
                              if (age != 25 && airBelow) {
                                 ungrownCaveVines++;
                              } else {
                                 grownCaveVines++;
                              }
                           }
                        }
                     }

                     if (this.vines.get()) {
                        if (state.isOf(Blocks.VINE)) {
                           BlockPos self = new BlockPos(x, y, z);
                           BlockState below = this.mc.world.getBlockState(self.down());
                           if (!below.isOf(Blocks.VINE)) {
                              if (!below.isAir()) {
                                 grownVines++;
                              } else {
                                 boolean attached = state.get(Properties.NORTH)
                                       || state.get(Properties.EAST)
                                       || state.get(Properties.SOUTH)
                                       || state.get(Properties.WEST);
                                 if (attached) {
                                    ungrownVines++;
                                 } else {
                                    grownVines++;
                                 }
                              }
                           }
                        }
                     }

                     if (this.amethyst.get() && !donut) {
                        if (state.isOf(Blocks.AMETHYST_CLUSTER)) {
                           grownAmethyst++;
                        } else if (state.isOf(Blocks.SMALL_AMETHYST_BUD)
                              || state.isOf(Blocks.MEDIUM_AMETHYST_BUD)
                              || state.isOf(Blocks.LARGE_AMETHYST_BUD)) {
                           if (state.contains(Properties.FACING)) {
                              Direction facing = state.get(Properties.FACING);
                              BlockPos behind = new BlockPos(x, y, z).offset(facing.getOpposite());
                              boolean budding = this.mc.world.getBlockState(behind).isOf(Blocks.BUDDING_AMETHYST);
                              if (budding) {
                                 ungrownAmethyst++;
                              } else {
                                 grownAmethyst++;
                              }
                           }
                        }
                     }

                     if (this.bamboo.get()) {
                        if (state.isOf(Blocks.BAMBOO)) {
                           if (state.contains(Properties.STAGE)) {
                              BlockPos abovePos = new BlockPos(x, y + 1, z);
                              BlockState above = this.mc.world.getBlockState(abovePos);
                              if (!above.isOf(Blocks.BAMBOO)) {
                                 int stage = state.get(Properties.STAGE);
                                 if (stage == 1) {
                                    grownBamboo++;
                                 } else if (above.isAir()) {
                                    ungrownBamboo++;
                                 }
                              }
                           }
                        }
                     }

                     if (this.beeNest.get()) {
                        if (state.isOf(Blocks.BEE_NEST)) {
                           if (state.contains(Properties.HONEY_LEVEL)) {
                              int honey = state.get(Properties.HONEY_LEVEL);
                              if (honey == 5) {
                                 grownBeeNest++;
                              } else {
                                 ungrownBeeNest++;
                              }
                           }
                        }
                     }

                     if (this.rotatedDeepslate.get()) {
                        if (state.isOf(Blocks.DEEPSLATE)) {
                           if (state.contains(Properties.AXIS)) {
                              if (state.get(Properties.AXIS) != Direction.Axis.Y && y >= 0 && y <= 60) {
                                 BlockPos self = new BlockPos(x, y, z);
                                 boolean buried = true;

                                 for (Direction direction : Direction.values()) {
                                    if (this.mc.world.getBlockState(self.offset(direction)).isAir()) {
                                       buried = false;
                                       break;
                                    }
                                 }

                                 if (buried) {
                                    rotated.add(self);
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      if (donut) {
         if (anyBud) {
            ungrownAmethyst++;
         } else if (anyCluster) {
            grownAmethyst++;
         }
      }

      int ungrown = this.kelp.get() ? ungrownKelp : 0;
      ungrown += this.caveVines.get() ? ungrownCaveVines : 0;
      ungrown += this.vines.get() ? ungrownVines : 0;
      ungrown += this.amethyst.get() ? ungrownAmethyst : 0;
      ungrown += this.bamboo.get() ? ungrownBamboo : 0;
      ungrown += this.beeNest.get() ? ungrownBeeNest : 0;
      int grown = this.kelp.get() ? grownKelp : 0;
      grown += this.caveVines.get() ? grownCaveVines : 0;
      grown += this.vines.get() ? grownVines : 0;
      grown += this.amethyst.get() ? grownAmethyst : 0;
      grown += this.bamboo.get() ? grownBamboo : 0;
      grown += this.beeNest.get() ? grownBeeNest : 0;
      return new ChunkScore(grown, ungrown > 0, rotated);
   }

   @EventHandler
   public void onRender(Render3DEvent event) {
      if (this.mc.world != null) {
         int alphaValue = this.alpha.getInt();
         int minimum = this.sensitivity.getInt();
         if (!this.heat.isEmpty()) {
            Color color = new Color(255, 0, 0, alphaValue);

            for (Map.Entry<ChunkPos, Integer> entry : this.heat.entrySet()) {
               ChunkPos chunkPos = entry.getKey();
               int value = entry.getValue();
               if (value >= minimum && !this.isVetoed(chunkPos)) {
                  if (this.mc.world.isChunkLoaded(chunkPos.x, chunkPos.z)) {
                     int scannedNeighbours = 0;

                     for (int dx = -1; dx <= 1; dx++) {
                        for (int dz = -1; dz <= 1; dz++) {
                           if (dx != 0 || dz != 0) {
                              if (this.scannedChunks.contains(new ChunkPos(chunkPos.x + dx, chunkPos.z + dz))) {
                                 scannedNeighbours++;
                              }
                           }
                        }
                     }

                     if (scannedNeighbours >= 3) {
                        event.renderer.box(
                              (double) chunkPos.getStartX(),
                              63.0,
                              (double) chunkPos.getStartZ(),
                              (double) (chunkPos.getStartX() + 16),
                              63.1,
                              (double) (chunkPos.getStartZ() + 16),
                              color, color, ShapeMode.Sides, 0);
                     }
                  }
               }
            }
         }

         if (!this.rotatedPositions.isEmpty()) {
            Color color = new Color(0, 255, 255, alphaValue);
            this.rotatedPositions.removeIf(pos -> !this.mc.world.isChunkLoaded(pos.getX() >> 4, pos.getZ() >> 4));

            for (BlockPos pos : this.rotatedPositions) {
               event.renderer.box(
                     (double) pos.getX(),
                     (double) pos.getY(),
                     (double) pos.getZ(),
                     (double) (pos.getX() + 1),
                     (double) (pos.getY() + 1),
                     (double) (pos.getZ() + 1),
                     color, color, ShapeMode.Sides, 0);
            }
         }
      }
   }

   public boolean isDonutFolia() {
      if (this.mc.getNetworkHandler() == null) {
         return false;
      } else {
         String brand = this.mc.getNetworkHandler().getBrand();
         if (brand != null && brand.contains("DonutFolia")) {
            return true;
         }

         return false;
      }
   }
}

package com.krypton.modules.basefinding;

import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;

import com.krypton.event.EventHandler;
import com.krypton.event.Render3DEvent;
import com.krypton.mixin.ChunkLightProviderAccessor;
import com.krypton.mixin.ChunkToNibbleArrayMapAccessor;
import com.krypton.mixin.LightStorageAccessor;
import com.krypton.system.Category;
import com.krypton.system.Module;
import com.krypton.util.Color;
import com.krypton.util.ShapeMode;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkSectionPos;
import net.minecraft.world.LightType;
import net.minecraft.world.chunk.ChunkNibbleArray;
import net.minecraft.world.chunk.ChunkToNibbleArrayMap;
import net.minecraft.world.chunk.light.ChunkLightProvider;
import net.minecraft.world.chunk.light.LightStorage;

import java.util.Iterator;

public class LightFinder extends Module {
    public LightFinder() {
        super("Light Finder", "Renders all light sections for base finding", -1, Category.BASE_FINDING);
    }

    @EventHandler
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public void onRender(Render3DEvent event) {
        if (this.mc.world != null && this.mc.player != null) {
            try {
                ChunkLightProvider lightProvider =
                        (ChunkLightProvider) this.mc.world.getLightingProvider().get(LightType.BLOCK);
                LightStorage lightStorage = ((ChunkLightProviderAccessor) lightProvider).getLightStorage();
                ChunkToNibbleArrayMap storage = ((LightStorageAccessor) lightStorage).getStorage();
                Long2ObjectOpenHashMap<ChunkNibbleArray> arrays =
                        ((ChunkToNibbleArrayMapAccessor) storage).getArrays();
                ObjectIterator<Long2ObjectMap.Entry<ChunkNibbleArray>> it =
                        arrays.long2ObjectEntrySet().iterator();

                while (((Iterator) it).hasNext()) {
                    Long2ObjectMap.Entry<ChunkNibbleArray> entry =
                            (Long2ObjectMap.Entry<ChunkNibbleArray>) ((Iterator) it).next();
                    long sectionKey = entry.getLongKey();
                    ChunkNibbleArray nibbles = entry.getValue();
                    if (nibbles != null && !nibbles.isArrayUninitialized()) {
                        ChunkSectionPos sectionPos = ChunkSectionPos.from(sectionKey);
                        int minX = sectionPos.getMinX();
                        int minY = sectionPos.getMinY();
                        int minZ = sectionPos.getMinZ();

                        for (int lx = 0; lx < 16; lx++) {
                            for (int ly = 0; ly < 16; ly++) {
                                for (int lz = 0; lz < 16; lz++) {
                                    int level = nibbles.get(lx, ly, lz);
                                    if (level != 0) {
                                        float intensity = (float) level / 15.0F;
                                        Color color = new Color(intensity, intensity, 0.2F, 0.3F);
                                        BlockPos pos = new BlockPos(minX + lx, minY + ly, minZ + lz);
                                        if (pos.getY() < 0) {
                                            event.renderer.box(
                                                    (double) pos.getX(),
                                                    (double) pos.getY(),
                                                    (double) pos.getZ(),
                                                    (double) (pos.getX() + 1),
                                                    (double) (pos.getY() + 1),
                                                    (double) (pos.getZ() + 1),
                                                    color, color, ShapeMode.Sides, 0);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
